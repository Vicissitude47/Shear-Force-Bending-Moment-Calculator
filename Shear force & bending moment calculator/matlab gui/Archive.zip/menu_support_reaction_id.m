
function support_reaction_id = menu_support_reaction_id

support_reaction_id = menu('Choose the support reaction that fit your problem', 'fixed support',...
    'one pin support', 'one pin support and one roller support','one roller support','two roller supports');

                     
end